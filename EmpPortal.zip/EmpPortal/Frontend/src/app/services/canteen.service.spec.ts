import { TestBed } from '@angular/core/testing';

import { CanteenService } from './canteen.service';

describe('CanteenService', () => {
  let service: CanteenService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(CanteenService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
